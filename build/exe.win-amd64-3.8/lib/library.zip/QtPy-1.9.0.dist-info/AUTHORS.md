Maintainer
==========

Gonzalo Peña-Castellanos ([@goanpeca](http://github.com/goanpeca))

Main Authors
============

* Colin Duquesnoy ([@ColinDuquesnoy](http://github.com/ColinDuquesnoy))

* [The Spyder Development Team](https://github.com/spyder-ide/spyder/graphs/contributors)

Contributors
============

* Thomas Robitaille ([@astrofrog](http://www.github.com/astrofrog))